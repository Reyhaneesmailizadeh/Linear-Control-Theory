
J = 0.01;
b = 0.1;
K = 0.01;
R = 1;
L = 0.5;
s = tf('s');
TF_speed = K/((J*s+b)*(L*s+R)+K^2)
P_motor = K/(s*((J*s+b)*(L*s+R)+K^2))
% A = [-b/J   K/J
%     -K/L   -R/L];
% B = [0
%     1/L];
% C = [1   0];
% D = 0;
% TF_ss = ss(A,B,C,D)

% linearSystemAnalyzer('step', TF_speed, 0:0.5:5);
Kp = 100;
Ki = 200;
Kd = 100;
C = pid(Kp,Ki,0);
s = tf('s');
T_d = 1; % Example delay time of 1 second
Delay = (1 - T_d*s/2) / (1 + T_d*s/2);
sys_cl = feedback(C*TF_speed,Delay);
sys_cl_p = feedback(C*P_motor,Delay);
t = 0:0.05:5;
step(sys_cl,t)
grid
% title('Step Response with Proportional Control')
% controlSystemDesigner(TF_speed)
% h = nyquistplot(sys_cl);
% Plot the Bode diagrams
figure;
subplot(2,1,1);
bode(sys_cl);
title('Bode Diagram of Closed-Loop System with TF_{speed}');
grid on;

subplot(2,1,2);
bode(sys_cl_p);
title('Bode Diagram of Closed-Loop System with P_{motor}');
grid on;